//
//  Conference.h
//  bistriAPI2
//
//  Created by Aurélien Hiron on 06/04/2023.
//

#import <Foundation/Foundation.h>
#import <AVFAudio/AVFAudio.h>

//! Project version number for bistriAPI2.
FOUNDATION_EXPORT double bistriAPI2VersionNumber;

//! Project version string for bistriAPI2.
FOUNDATION_EXPORT const unsigned char bistriAPI2VersionString[];


#import "bistriAPI2/peer_stream.h"


/**
 * Media type
 */
typedef enum {
	AUDIO, /**< Audio */
	VIDEO /**< Video */
} MediaType;

/**
 * Conference event
 */
typedef enum {
	in_room, /**< In Room */
	out_room /**< Out of room */
} ConfEvent;

/**
 * Conference connection status
 */
typedef enum {
	DISCONNECTED, /**< Disconnected */
	CONNECTING, /**< Connecting */
	CONNECTING_SENDREQUEST, /**< Connecting, send authentication request */
	CONNECTED /**< Connected */
} ConferenceConnection;

/**
 * Conference Error
 */
typedef enum {
	NO_ERROR, /**< No error */
	CONNECTION_ERROR /**< Connection error */
} ConferenceError;

/**
 * User presence
 */
typedef enum {
	ONLINE, /**< Online */
	AWAY, /**< Away */
	BUSY, /**< Busy */
	OFFLINE /**< Offline */
} Presence;

/**
 * Video options
 */
typedef enum {
	PREFERRED_VIDEO_CODEC, /**< Set the preferred video codec */
	MIN_WIDTH, /**< Set minimum width */
	MIN_HEIGHT, /**< Set minimum height */
	MAX_WIDTH, /**< Set maximum width */
	MAX_HEIGHT, /**< Set maximum height */
	MAX_FRAME_RATE /**< Set maximum frame rate */
} ConferenceVideoOption;


/**
 * General options
 */
typedef enum {
	ENABLE_STATS,
	DISABLE_AUTORECONNECT,  /**< Disable auto reconnection. (Auto reconnecting is enable by default). */
	DISABLE_AUTOCALL,  /**< Disable the automatic call of room members when user join a room. (Auto calling is enable by default). */
	SEND_ONLY,  /**< Send only. No remote media stream is needed. */
	SEND_AUDIO, /**< Send audio. True by default */
	SEND_VIDEO, /**< Send video. True by default */
	RECEIVE_AUDIO, /**< Receive audio. True by default */
	RECEIVE_VIDEO  /**< Receive video. True by default */
} ConferenceGeneralOption;

/**
 * Audio options
 */
typedef enum {
	PREFERRED_AUDIO_CODEC, /**< Set the preferred audio codec */
	PREFERRED_AUDIO_CODEC_CLOCKRATE /**< Set the preferred audio codec clock rate */
} ConferenceAudioOption;

/**
 * Video codec available
 */
typedef enum {
	VP8,  /**< Codec of the WebM Project */
	H264  /**< Advanced Video Coding */
} ConferenceVideoCodec;

/**
 * Audio codec available
 */
typedef enum {
	OPUS, /**< The IETF Opus codec */
	ISAC, /**< internet Speech Audio Codec */
	PCMU, /**< Pulse Code Modulation μ-law */
	PCMA, /**< Pulse Code Modulation a-law */
	CN /**< Comfort Noise */
} ConferenceAudioCodec;

/**
 * Room member. Also known as a peer.
 */
@interface Member : NSObject

/**
 * Identifier
 * @return identifier
 */
@property (nonatomic, copy) NSString* id;

/**
 * Name
 * @return member name
 */
@property (nonatomic, copy) NSString* name;

/**
 * Init member
 * @param (NSString) id.
 * @param (NSString) name.
 * @return (id) id.
 */
- (id)initWithPeerId:(NSString *)id andPeerName:(NSString *)name;
@end

/**
 * Conference event delegate
 */
@protocol ConferenceDelegate <NSObject>
@required
/**
 * Called on connection event.
 *
 * @param (ConferenceConnection) status.
 */
- (void)onConnectionEvent: (ConferenceConnection)status;

/**
 * Called on error event
 *
 * @param (ConferenceError) error
 */
- (void)onError: (ConferenceError)error;

/**
 * Called when a room is joined
 *
 * @param (NSString) roomName
 */
- (void)onRoomJoined: (NSString*)roomName;

/**
 * Called when the current room is quitted
 *
 * @param (NSString) roomName
 */
- (void)onRoomQuitted: (NSString*)roomName;

/**
 * Called when a peer join the room is quitted
 *
 * @param (NSString) roomName.
 * @param (NSString) peerId. Peer identifier.
 * @param (NSString) peerName. Peer name.
 */
- (void)onPeerJoinedRoom: (NSString*)roomName peerId:(NSString*)peerId peerName:(NSString*)peerName;

/**
 * Called when peer left the room
 *
 * @param (NSString) roomName
 * @param (NSString) peerId. Peer identifier.
 */
- (void)onPeerQuittedRoom: (NSString*)roomName peerId:(NSString*)peerId;

/**
 * Called when a new peer is available
 *
 * @param (PeerStream) peerStream
 */
- (void)onNewPeer: (PeerStream*)peerStream;

/**
 * Called when a peer has left the room
 *
 * @param (PeerStream) peerStream
 */
- (void)onRemovedPeer: (PeerStream*)peerStream;

/**
 * Called when a presence is received (fired by GetPresence).
 *
 * @param (NSString) peerId. Peer identifier.
 * @param (Presence) presence.
 */
- (void)onPresence: (NSString*)peerId presence:(Presence)presence;

/**
 * Called when a presence is received (fired by GetPresence).
 *
 * @param (NSString) peerId. Peer identifier.
 * @param (NSString) peerName. Peer name.
 * @param (NSString) room. Room name.
 * @param (NSString) callEvent. Call event.
 */
- (void)onIncomingRequest: (NSString*)peerId name:(NSString*)peerName room:(NSString*)room callEvent:(NSString*)event;

/**
 * Called when getMembers result is ready
 *
 * @param (NSString) roomName
 * @param (NSArray) members
 */
- (void)onRoomMembers: (NSString*)room members:(NSArray*)members;
@end

/**
 * Conference
 */
@interface Conference : NSObject

/**
 * convert Presence to String
 *
 * @param (Presence) presence.
 * @return (NSString)
 */
+(NSString*) presenceToString:(Presence) presence;

/**
 * convert Presence from String
 *
 * @param (NSString) presence.
 * @return (Presence)
 */
+(Presence) presenceFromString:(NSString*) presence;

@property (nonatomic, assign) id<ConferenceDelegate> delegate;

/**
 * Get the current instance of conference object.
 *
 * @return Conference object or null if no previous instance already exists.
 */
 + (Conference*) getInstance;

/**
 * Set credential information.
 * WARNING: Your application package name is automaticaly used as "referrer".
 *
 * @param (NSString) appId. Your application Identifier
 * @param (NSString) apiKey. Your application Key
 * @param (NSString) userName. User name
 * @return True if appId and appKey seem valid.
 */
- (BOOL) setInfoWithAppID:(NSString*)appId APIKey:(NSString*)apiKey userName:(NSString*)userName;

/**
 * Set credential information.
 * WARNING: Your application package name is automaticaly used as "referrer".
 *
 * @param (NSString) appId. Your application Identifier
 * @param (NSString) apiKey. Your application Key
 * @param (NSString) userName. User name
 * @param (NSString) userId. User identifier
 * @return True if appId and appKey seem valid.
 */
- (BOOL) setInfoWithAppID:(NSString*)appId APIKey:(NSString*)apiKey userName:(NSString*)userName userId:(NSString*)userId;

/**
 * Connect to conference service.
 */
- (void) connect;

/**
 * Disconnect.
 */
- (void) disconnect;

/**
 * Get the connection status.
 *
 * @return ConferenceConnection.
 */
- (ConferenceConnection) getStatus;

/**
 * Join a room.
 *
 * @param (NSString) roomName. The room name you want to join. It can be an existing one, or a new one. roomName can contains only a-z,A-Z,0-9,-,_
 */
- (void) join: (NSString*)roomName;

/**
 * Leave the specified room.
 *
 * @param (NSString) roomName.
 */
- (void) leave: (NSString*)roomName;

/**
 * Call the specified peerId in the specified room
 *
 * @param (NSString) peerId. Peer identifier.
 * @param (NSString) roomName. The room where the call take place. Room name can contains only a-z,A-Z,0-9,-,_
 */
- (void) call:(NSString*)peerId inRoom:(NSString*)roomName;

/**
 * Open a DataChannel with the current peer in the specified room.
 *
 * @param (NSString) peerId. Peer identifier.
 * @param (NSString) label. Data stream label.
 * @param (NSString) roomName. The room where the call take place. Room name can contains only a-z,A-Z,0-9,-,_
 */
- (void) openDataChannel:(NSString*)peerId  withLabel:(NSString*)label inRoom:(NSString*)roomName;

/**
 * Enable/disable loud speaker.
 *
 * @param (bool) enable.
 */
- (void) setLoudspeaker:(bool) enable;

/**
 * Return the current room name.
 *
 * @return the current room name. If no room is joined, null is returned.
 */
- (NSString*) getRoomName;

/**
 * Mute/Unmute an audio or video stream.
 *
 * @param (bool) mute. True will mute selected stream, false will unmute it.
 * @param (NSString) room. Room name.
 * @param (NSString) peerId. Peer identifier.
 * @param (MediaType) type the media (AUDIO/VIDEO).
 */
- (void) mute:(bool)mute room:(NSString*)room peerId:(NSString*)peerId type:(MediaType)type;

/**
 * Return the local peer stream.
 *
 * @return PeerStream.
 */
- (PeerStream*) getLocalStream;

/**
 * Return a peer stream from peer ID.
 *
 * @param (NSString) peerId. Peer identifier.
 * @return PeerStream.
 */
- (PeerStream*) getPeerStream: (NSString*) peerId;

/**
 * Return an identifiers array of peers currently in the room.
 *
 * @return NSArray;
 */
- (NSArray*) getPeerStreamIds;

/**
 * Remove peer stream
 *
 * @param (NSString) peerId. Peer identifier.
 */
- (void) removePeerStream: (NSString*) peerId;


/**
 * Set the camera facing.
 * Can be used during acal.l
 *
 * @param (bool) true for front camera.
 */

- (void) setCameraFacingFront: (bool) front;

// General options

/**
 * Set general options.
 *
 * @param (ConferenceGeneralOption) option.
 * @param (bool) value.
 */
- (void) setGeneralOption:(ConferenceGeneralOption)option withValue:(bool)value;

/**
 * Check if a general option has been set.
 *
 * @param (ConferenceGeneralOption) option.
 * @return True if the given option has already been set.
 */
- (bool) hasGeneralOption:(ConferenceGeneralOption)option;


/**
 * Get general option has String.
 *
 * @param (ConferenceGeneralOption) option.
 * @return value has a String if possible, null otherwise.
 */
- (NSString*) getGeneralOptionAsString:(ConferenceGeneralOption)option;

// Video options
/**
 * Set video options.
 *
 * @param (ConferenceVideoOption) option.
 * @param (ConferenceVideoCodec) value.
 */
- (void) setVideoOption:(ConferenceVideoOption)option withCodecValue:(ConferenceVideoCodec)value;

/**
 * Get video option has ConferenceVideoCodec enum.
 *
 * @param (ConferenceVideoOption) option.
 * @return ConferenceVideoCodec value.
 */
- (ConferenceVideoCodec) getVideoOptionAsVideoCodec:(ConferenceVideoOption)option;

/**
 * Set video options.
 *
 * @param (ConferenceVideoOption) option
 * @param (int) value
 */
- (void) setVideoOption:(ConferenceVideoOption)option withIntValue:(int)value;

/**
 * Check if a video option has been set.
 *
 * @param (ConferenceVideoOption) option.
 * @return True if the given option has already been set.
 */
- (bool) hasVideoOption:(ConferenceVideoOption)option;

/**
 * Get video option has int.
 *
 * @param (ConferenceVideoOption) option.
 * @return value if possible, null otherwise.
 */
- (int) getVideoOptionAsInteger:(ConferenceVideoOption)option;

/**
 * Get video option has String.
 *
 * @param (ConferenceVideoOption) option.
 * @return value has a String if possible, null otherwise.
 */
- (NSString*) getVideoOptionAsString:(ConferenceVideoOption)option;

// Audio options
/**
 * Set audio options.
 *
 * @param (ConferenceAudioOption) option.
 * @param (ConferenceAudioCodec) value.
 */
- (void) setAudioOption:(ConferenceAudioOption)option withCodecValue:(ConferenceAudioCodec)value;

/**
 * Set audio options.
 *
 * @param (ConferenceAudioOption) option.
 * @param (int) value.
 */
- (void) setAudioOption:(ConferenceAudioOption)option withIntValue:(int)value;

/**
 * Check if an audio option has been set.
 *
 * @param (ConferenceAudioOption) option.
 * @return True if the given option has already been set.
 */
- (bool) hasAudioOption:(ConferenceAudioOption)option;

/**
 * Get audio option has ConferenceAudioCodec enum.
 *
 * @param (ConferenceAudioOption) option.
 * @return ConferenceAudioCodec value.
 */
- (ConferenceAudioCodec) getAudioOptionAsAudioCodec:(ConferenceAudioOption)option;

/**
 * Get audio option has integer.
 *
 * @param (ConferenceAudioOption) option.
 * @return int value.
 */
- (int) getAudioOptionAsInt:(ConferenceAudioOption)option;

/**
 * Get audio option has String.
 *
 * @param (ConferenceAudioOption) option.
 * @return String value.
 */
- (NSString*) getAudioOptionAsString:(ConferenceAudioOption)option;

/**
 * Get your own user identifier. This identifier is set by the conference server after been connected.
 *
 * @return String identifier if any, it return null otherwise.
 */
- (NSString*) getUserId;

/**
 * Set your own presence.
 *
 * @param (Presence) presence.
 * @see Presence
 */
- (void) setPresence: (Presence) presence;

/**
 * Get presence of a remote peer.
 *
 * @param (NSString) peerId remote user identifier
 */
- (void) getPresence: (NSString*) peerId;

/**
 * Get members of a room.
 *
 * @param (NSString) roomName. The room name
 */
- (void) getMembers: (NSString*) roomName;

/**
 * Informs api that application is active.
 */
- (void) applicationIsActive;

/**
 * Informs api that application enter in background.
 */
- (void) applicationInBackground;

/**
 * Specifies an asset image name to display when the camera is unavailable.
 */
- (void) setNoCameraImage: (NSString*) imageName;

/**
 * Specifies whether the audio session should be handled automatically.
 */
- (void) manageAudioMode: (bool) enable;

/**
 * Specifies whether the audio session has been activated and ready to be used.
 */
- (void) audioSessionDidActivate: (AVAudioSession *)audioSession;

/**
 * Specifies whether the audio session has been deactivated.
 */
- (void) audioSessionDidDeactivate: (AVAudioSession *)audioSession;

@end
