#import <Foundation/Foundation.h>
#import "media_stream.h"
#import "data_stream.h"

@class Conference;

/**
 * PeerStream Delegate
 */
@protocol PeerStreamDelegate;

/**
 * PeerStream Object
 */
@interface PeerStream : NSObject
@property (nonatomic, assign) id<PeerStreamDelegate> delegate;

/**
 * Get peer identifier of this stream
 *
 * @return (NSString).
 */
- (NSString*) getId;

/**
 * Test if the peer stream is local or not.
 *
 * @return True if the peer stream is the local one.
 */
- (BOOL) isLocal;

/**
 * Test if peer stream contains a media stream
 *
 * @return True if peer stream contains a media stream, false otherwise.
 */
- (BOOL) hasMedia;

/**
 * Get the media stream, if any.
 *
 * @return (MediaStream).
 */
- (MediaStream*) getMedia;

/**
 * Open a data stream whith this peer.
 * @param (NSString) label. The DataStream label
 *
 * @return (DataStream).
 */
-(DataStream*) openDataChannel: (NSString*)label;

@end

/**
 * Peer Stream Handler
 */
@protocol PeerStreamDelegate <NSObject>
@required

/**
 * Called when media stream is available.
 *
 * @param (MediaStream) mediaStream. The media stream.
 * @param (NSString) peerId. The peer identifier.
 */
- (void)onMediaStream: (MediaStream*) mediaStream peerId: (NSString*)peerId;

/**
 * Called when a DataStream is available.
 *
 * @param (DataStream) dataStream. The data stream.
 * @param (NSString) peerId. The peer identifier
 */
- (void)onDataStream: (DataStream*) dataStream peerId: (NSString*)peerId;
@end
