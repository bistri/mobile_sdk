#ifndef bistri_ios_render_view_h
#define bistri_ios_render_view_h

#include <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

/**
 * VideoView Object
 */
@interface VideoView : NSObject

/**
 * Get the current view
 *
 * @return (UIView).
 */
- (UIView*) getView;
- (void) stopRendering;
- (void) startRendering;
@end

#endif
