//
//  peer_stream_wrapper.h
//  bistriAPI2
//
//  Created by Aurélien Hiron on 09/05/2023.
//

#ifndef peer_stream_wrapper_h
#define peer_stream_wrapper_h

#import <bistriAPI2/conference.h>
#import <WebRTC/RTCMediaStream.h>
#import <WebRTC/RTCMTLVideoView.h>
#import <WebRTC/RTCDataChannel.h>


@interface ObjectsWrapper : NSObject
+ (PeerStream*)CreatePeerStream:(NSString *)peerId;
+ (void)PeerStreamSetMedia:(PeerStream*)peerStream media:(RTCMediaStream*)rtcMediaStream;
+ (void)PeerStreamSetDataStream:(PeerStream*)peerStream label:(NSString*)label channel:(RTCDataChannel*)channel;
+ (void)PeerStreamClose:(PeerStream*)peerStream;
+ (void)PeerStreamSetOriginalCall:(PeerStream*)peerStream call:(NSObject*)call;
+ (RTCMTLVideoView*)VideoViewGetRenderer:(VideoView*)videoView;
@end

#endif /* peer_stream_wrapper_h */
