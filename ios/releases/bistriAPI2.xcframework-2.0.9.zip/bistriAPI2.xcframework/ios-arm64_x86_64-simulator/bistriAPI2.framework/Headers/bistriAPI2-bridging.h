//
//  bistriAPI2-briging.h
//  bistriAPI2
//
//  Created by Aurélien Hiron on 18/04/2023.
//

#ifndef bistriAPI2_briging_h
#define bistriAPI2_briging_h

#import <bistriAPI2/Conference.h>

#endif /* bistriAPI2_briging_h */
