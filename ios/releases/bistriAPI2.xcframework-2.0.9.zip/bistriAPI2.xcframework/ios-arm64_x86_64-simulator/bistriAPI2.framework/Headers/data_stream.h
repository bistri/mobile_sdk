#import <Foundation/Foundation.h>

/**
 * Connection status
 */
typedef enum {
    PENDING, /**< Channel not ready */
    OPEN, /**< Channel connected */
    CLOSED /**< Channel closed */
} Status;


/**
 * DataStream Delegate
 */
@protocol DataStreamDelegate;

/**
 * DataStream Object
 */

@interface DataStream : NSObject
@property (nonatomic, assign) id<DataStreamDelegate> delegate;

/**
 * Send data through DataStream
 *
 * @param (NSData) message. Data to send.
 * @param (BOOL) binary. Binary flag. Set to false for a string.
 */
- (void) send:(NSData*)message isBinary:(BOOL)binary;

/**
 * Send data through DataStream
 * @param (NSString) message. String data to send.
 */
- (void) send:(NSString*)message;

/**
 * Get DataStream label
 *
 * @return (NSString) the label.
 */
- (NSString*) getLabel;

/**
 * Get the status of DataStream
 *
 * @return (Status) of this DataStream
 */
- (Status) getStatus;

/**
 * Close DataStream
 */
- (void) close;
@end

/**
 * DataStream handler.
 */
@protocol DataStreamDelegate <NSObject>
@required

/**
 * Called when the DataStream is open and ready to send/receive data.
 *
 * @param (DataStream) dataStream.
 */
- (void) onOpen: (DataStream*) dataStream;

/**
 * Called when a (NSData) message is received.
 *
 * @param (DataStream) dataStream
 * @param (NSData) message. The message receive
 * @param (BOOL) isBinary. True if the message is binary
 */
- (void) onMessage: (DataStream*) dataStream message:(NSData*)message isBinary:(BOOL)binary;

/**
 * Called when the DataStream is closed
 *
 * @param (DataStream) dataStream
 */
- (void) onClose: (DataStream*) dataStream;

/**
 * Called when an error occurred
 *
 * @param (DataStream) dataStream
 * @param (NSString) error. The error
 */
- (void) onError: (DataStream*) dataStream error:(NSString*)error;
@end
