#import <Foundation/Foundation.h>
#import "video_view.h"

/**
 * MediaStream Delegate
 */
@protocol MediaStreamDelegate;
@class PeerStream;

/**
 * MediaStream Object
 */
@interface MediaStream : NSObject
@property (nonatomic, assign) id<MediaStreamDelegate> delegate;

/**
 * Test if this media stream has video.
 *
 * @return True if the media stream has video, false otherwise.
 */
- (BOOL) hasVideo;

/**
 * Return the video ratio.  ( width / height ).
 *
 * @return (float) video ratio.
 */
- (float) getVideoRatio;

/**
 * Return video width.
 *
 * @return (int) video width.
 */
- (int) getVideoWidth;

/**
 * Return video height.
 *
 * @return (int) video height.
 */
- (int) getVideoHeight;

/**
 * Return the current peer stream.
 *
 * @return (PeerStream).
 */
- (PeerStream*) getPeerStream;

/**
 * Return the current video view.
 *
 * @return (VideoView).
 */
- (VideoView*) getVideoView;
@end

/**
 * MediaStream handler.
 */
@protocol MediaStreamDelegate <NSObject>
@required

/**
 * Called when the video ratio change. This can happen when a phone is rotate from landscape to portrait.
 *
 * @param (float) ratio. Ratio of the video.
 * @param (MediaStream). The media stream.
 */
- (void)onVideoRatioChange:(float)ratio media:(MediaStream*)mediaStream;

/**
 * Called when the video size has changed.
 * This can happen when a phone is rotated from landscape to portrait
 * or when remote peer adapts video size according to available bandwidth..
 * This is also called on the first received frame of the video.
 *
 * @param (int) width. With of the video.
 * @param (int) height. Height of the video.
 * @param (MediaStream). The media stream.
 */
- (void)onVideoSizeChange:(int)width height:(int)height media:(MediaStream*)mediaStream;

/**
 * Called when first video frame is received.
 *
 * @param (MediaStream). The media stream.
 */
- (void)onVideoReady:(MediaStream*)mediaStream;
@end
